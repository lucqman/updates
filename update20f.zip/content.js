chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action === "pesquisarLucqmanFilmes") {
        window.location.href = `lucqman-filmes://pesquisar?texto=${request.texto}&type=${request.tipo}`;
        sendResponse({ ok: true });
    }
});
