chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "lucqman-filmes-filme",
    title: "Pesquisar em (Filmes)",
    contexts: ["selection"]
  });

  chrome.contextMenus.create({
    id: "lucqman-filmes-serie",
    title: "Pesquisar em (Séries)",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const tipo = info.menuItemId === "lucqman-filmes-serie" ? "serie" : "filme";
  const texto = encodeURIComponent(info.selectionText);

  // Sempre chama o protocolo para garantir que a janela seja trazida à frente
  const url = `lucqman-filmes://pesquisar?texto=${texto}&type=${tipo}`;
  chrome.tabs.create({ url });
});
